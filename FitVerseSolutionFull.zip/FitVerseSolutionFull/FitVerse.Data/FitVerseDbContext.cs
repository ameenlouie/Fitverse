using Microsoft.EntityFrameworkCore;
using FitVerse.Core.Models;

namespace FitVerse.Data;

public class FitVerseDbContext : DbContext {
    public FitVerseDbContext(DbContextOptions<FitVerseDbContext> options) : base(options){}
    public DbSet<User> Users => Set<User>();
}
