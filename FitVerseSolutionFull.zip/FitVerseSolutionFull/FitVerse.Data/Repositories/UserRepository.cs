using FitVerse.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace FitVerse.Data.Repositories;

public class UserRepository {
    private readonly FitVerseDbContext _db;
    public UserRepository(FitVerseDbContext db)=>_db=db;

    public IEnumerable<User> GetAll()=>_db.Users.ToList();
    public User? Get(int id)=>_db.Users.Find(id);
    public User Create(User u){_db.Users.Add(u);_db.SaveChanges();return u;}
    public User Update(User u){_db.Users.Update(u);_db.SaveChanges();return u;}
    public void Delete(int id){var x=_db.Users.Find(id); if(x!=null){_db.Users.Remove(x);_db.SaveChanges();}}
}
