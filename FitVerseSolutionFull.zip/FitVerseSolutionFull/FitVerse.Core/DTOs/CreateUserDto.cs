namespace FitVerse.Core.DTOs;
public record CreateUserDto(string Name,int Age,double HeightCm,double WeightKg);
