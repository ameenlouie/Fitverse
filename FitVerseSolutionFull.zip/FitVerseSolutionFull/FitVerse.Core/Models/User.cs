namespace FitVerse.Core.Models;
public class User {
    public int Id {get;set;}
    public string Name {get;set;} = "";
    public int Age {get;set;}
    public double HeightCm {get;set;}
    public double WeightKg {get;set;}
}