using Microsoft.AspNetCore.Mvc;
using FitVerse.Data.Repositories;
using FitVerse.Core.Models;

namespace FitVerse.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase {
    private readonly UserRepository _repo;
    public UsersController(UserRepository repo)=>_repo=repo;

    [HttpGet] public IActionResult Get()=>Ok(_repo.GetAll());
    [HttpGet("{id}")] public IActionResult Get(int id)=>_repo.Get(id) is User u ? Ok(u) : NotFound();
    [HttpPost] public IActionResult Post(User u){var c=_repo.Create(u); return Created("",c);}
    [HttpPut("{id}")] public IActionResult Put(int id,User u){u.Id=id; return Ok(_repo.Update(u));}
    [HttpDelete("{id}")] public IActionResult Delete(int id){_repo.Delete(id);return NoContent();}
}
